$(document).ready(function(){
    $("#resortsearch").selectmenu(); //Using JQuery UI select menu
});

$(document).ready(function(){
    $("#resortlevel").selectmenu(); //Using JQuery UI select menu
});

$(document).ready(function(){
    $("#resortcheckin").selectmenu(); //Using JQuery UI select menu
});





$(document).ready(function(){
    $("#slider-range").slider({      //Using JQuery UI slider option for price range
        range: true,
        min: 1254,
        max: 4499,
        slide: function(event,ui){
            $("#amountRange").val("£" + ui.values[0] + " - £" + ui.values[1]);
        }
    });

    $("#amountRange").val("£" + $("#slider-range").slider("values",0) + " - £" + $("#slider-range").slider("values",1));
});


$(document).ready(function(){
    $('input[type="button"]').button(); //Making use of UI Widgets (Button Widget)
});

function validateSearchResort(){  //function whihc is used to get the selected value from the dropdown list

    var selectDestination = document.getElementById("resortsearch");
    var selectDestinationValue = selectDestination.options[selectDestination.selectedIndex].text;   //Getting the destination value from the select box list

    var resortlevel = document.getElementById("resortlevel");    
    var resortLevelValue =  resortlevel.options[resortlevel.selectedIndex].text;   //Getting the selected value from the drop down list

    var resortCheckIn = document.getElementById("resortcheckin");
    var resortCheckInValue = resortCheckIn.options[resortCheckIn.selectedIndex].text; //Getting the selected value from the drop downlist
    
    if(selectDestinationValue == "Select" ||resortLevelValue  == "Select" || resortCheckInValue == "Select" ){
        alert("Please select all the options !");
    }
}


var data= { //Setting up the json data. 

"resorts": [
{
"id":"resort1",
"destination":"Alps",
"name":"Coeur des Alps",
"location":"Switzerland",
"comfortLevel": "4",
"activities":{
    "activity1":"golf", 
    "activity2":"tennis",
    "activity3": "hiking"
},
"price":1499,
"startDate":"2017-06-05",
"endDate":"2019-12-31",
"short_description":"Relax and experience the true meaning of luxury,Perfect for skiing holidays and snowboarding holidays,Great for family ski holidays and ski trips with friends",
"picture":"images/alpsmain.jpg",
"long_description":"Welcome to your home away from home. Simply sit back, relax and experience the true meaning of a luxury all inclusive ski holiday with Destination Ski. The climate whilst skiing in France can vary hugely depending on where you choose to take your break. The French Alps can receive a lot of snow in winter, due to its naturally dry, cold continental climate. Winter sports enthusiasts are generally given the best of the snow in our French Alps resorts, with slopes of up to 3,000m high sitting in the most fruitful area for frost in the Alps.",
"url":"resort1.html"
},
{
"id":"resort2",
"destination":"Europe",
"name":"Corfu Imperial Grecotel Exclusive Resort",
"location":"Greece",
"comfortLevel": "5",
"activities":["water skiing", "tennis", "scuba diving", "spa"],
"price":4499,
"startDate":"2017-07-05",
"endDate":"2019-11-31",
"short_description":"Relax and experience the true meaning of luxury,This spacious all-inclusive family resort in Greece has so much to explore,Try our fun leisure activities and lively evening entertainment,Enjoy delicious French cuisine and unforgettable aprés ski,If you have a thirst for adventure, choose our excursions.",
"picture":"images/europemain.jpg",
"long_description":"Welcome to your home away from home. Simply sit back, relax and experience the true meaning of a luxury all inclusive ski holiday with Destination Ski. Set on the island of Evia along a secluded beach,Corfu Imperial Grecotel Exclusive Resort is a paradise for watersport lovers and active families",
"url":"resort2.html"
},
{
"id":"resort3",
"destination":"Africa",
"name":"Bahama House Resort",
"location":"Bahamas",
"comfortLevel": "3",
"activities":["sailing","water skiing","scuba diving", "spa"],
"price":2500,
"startDate":"2017-03-05",
"endDate":"2019-10-31",
"short_description":"Relax and experience the true meaning of luxury,Try our fun leisure activities and lively evening entertainmen.Enjoy delicious French cuisine and unforgettable aprés ski",
"picture":"images/africamain.jpeg",
"long_description":"Harbour Island has always been a bit of a Caribbean insider’s secret. Pink sand beaches, pastel-painted houses draped with colorful bougainvillea, turquoise waters and distinct cultural heritage cast a spell on all who visit. With just 11 rooms, Bahama House feels more like a stylish friend’s beach retreat. A freshwater swimming pool and handcrafted tiki bar make it hard to leave. Luckily, guests don’t have to go far to experience local culture",
"url":"resort3.html"
},
{
"id":"resort4",
"destination":"Caribbean",
"name":"Les Boucaniers",
"location":"Martinique",
"comfortLevel": "5",
"activities":["tennis","water skiing",  "scuba diving", "spa"],
"price":1254,
"startDate":"2017-05-05",
"endDate":"2019-09-31",
"short_description":"The resort of Les Boucaniers is located on the laid-back beach-covered south coast of the island, and is perfectly placed for Martinique holidays that are both relaxing and awe-inspiring.",
"picture":"images/caribbeanmain.jpg",
"long_description":"A divers' paradise in the Baie du Marin, a legendary spot.<br>Its bungalows are discreetly lodged in a tropical garden beside the white sand beach in superb Marin Bay. A magical site where you can enjoy a taste of everything, alone or with family or friends. Try water sports and the magnificent Club Med Spa*. You'll be enchanted by the exotic flavours of the local cuisine and the joyful spirit of the Caribbean.",
"url":"resort4.html"
},
{
"id":"resort5",
"destination":"Indian Ocean",
"name":"La Plantation d'Albion",
"location":"Mauritius",
"comfortLevel": "4",
"activities":["kids club","golf", "scuba diving", "tennis", "sailing", "spa"],
"price":2062,
"startDate":"2017-01-01",
"endDate":"2019-05-31",
"short_description":"Beautifully located in one of the last remote creeks on the island, La Plantation d'Albion Club Med welcomes the most demanding of guests into a world of supreme refinement.",
"picture":"images/indianmain.jpg",
"long_description":"In a remote beauty spot, savour the luxury of Mauritian lifestyle. <br> The idyllic natural setting is enhanced by the sublime decor designed by Marc Hertrich and Nicolas Adnet, and the Resort's top-end comfort is perfectly reflected in its beautifully spacious rooms. The exceptional CINQ MONDES Spa* and luxurious overflow pool add an ideally Zen touch.<br> The Resort is entirely devoted to fulfilling its guests' desires and offers discreet, personal service in its swimming areas, bars and 'Table Gourmet' restaurants.",
"url":"resort5.html"
},

{
"id":"resort6",
"destination":"America",
"name":"Cleopatra Luxury Beach Resort",
"location":"Makadi",
"comfortLevel": "3",
"activities":["horse riding", "tennis", "scuba diving","kids club"],
"price":2550,
"startDate":"2017-02-05",
"endDate":"2019-07-31",
"short_description":"Beautifully located in one of the last remote creeks on the island.Cleopatra Luxury Beach Resort welcomes the most demanding of guests.Try our fun leisure activities and lively evening entertainment.Enjoy delicious French cuisine and unforgettable aprés ski.If you have a thirst for adventure, choose our excursions.",
"picture":"images/americamain.webp",
"long_description":"With its bungalows nestling in a colourful, tropical coconut grove, or on stilts on the river, this Brazilian holiday Resort lies alongside a secluded beach, a short ride from buzzing Salvador de Bahia. Between exhilarating moments on the flying trapeze and games of tennis, make the most of the coast to play beach volleyball. Ideal for a family break or holiday.",
"url":"resort6.html"
},
{
"id":"resort7",
"destination":"Asia",
"name":"Grand Hyatt Hotel & Villas",
"location":"Doha",
"comfortLevel": "4",
"activities":[ "spa","water skiing", "tennis", "scuba diving"],
"price":2550,
"startDate":"2017-01-05",
"endDate":"2019-02-31",
"short_description":"The resort of Les Boucaniers is located on the laid-back beach-covered south coast of the island, and is perfectly placed for Martinique holidays that are both relaxing and awe-inspiring.",
"picture":"images/asiamain.jpg",
"long_description":"With its bungalows nestling in a colourful, tropical coconut grove, or on stilts on the river, this Brazilian holiday Resort lies alongside a secluded beach, a short ride from buzzing Salvador de Bahia. Between exhilarating moments on the flying trapeze and games of tennis, make the most of the coast to play beach volleyball. Ideal for a family break or holiday.",
"url":"resort7.html"
}

]}





$(document).ready(function(){       //Checking whether the DOM is ready.

    var button = document.getElementById("search");     //Getting the button element by its ID.

    button.addEventListener("click", function(){        //Adding the button an event listener 

    var destination = document.getElementById("resortsearch");      //Getting the element by its ID
    var destinationSelected =destination.options[destination.selectedIndex].text;   //Getting the selected text.

    var level = document.getElementById("resortlevel");    //Getting the element by its ID
    var levelSelected = level.options[level.selectedIndex].text;     //Getting the selected text.

    var checkIn = document.getElementById("resortcheckin");    //Getting the element by its ID
    var checkInSelected = checkIn.options[checkIn.selectedIndex].text;     //Getting the selected text.

    var minimumPrice = $("#slider-range").slider("option","values")[0];     //Getting the minimum value in the slider.
    var maximumPrice = $("#slider-range").slider("option", "values")[1];    //Getting the maximum value in the slider.

    var outPutOfData = "";      //Creating a variable to hold the search results.

    var searchResultsDiv = document.getElementById("searchResultsResort");    //Getting the element by its ID.

    for(i=0; i < data.resorts.length; i++){     //Creating a for loop to iterate amoong the json data.

        //Checking whether the selected data matches with json data.

        if((destinationSelected == data.resorts[i].destination)){
            if((levelSelected >= data.resorts[i].comfortLevel)){
                if((checkInSelected== data.resorts[i].startDate)){
                        if((data.resorts[i].price >= minimumPrice) && (data.resorts[i].price <= maximumPrice)){
                            outPutOfData += "<h2 id='searchPrice'><li>"+"Price : £"+data.resorts[i].price+"</li></h2>"+"<a href="+data.resorts[i].url+" id='anchor'><img src="+data.resorts[i].picture+" id='searchImages'></a>" + "<p id='searchDescription'>" +data.resorts[i].short_description+"</p>"; //Concatenation of search results.
                        }
                }
            }
        }
    }
    searchResultsDiv.insertAdjacentHTML('beforeend',outPutOfData);  //Populating the output of the search results in a div.

    if(document.getElementById("searchResultsResort").innerHTML === ""){
        alert("Sorry No Results Found ! ");     //alert displayed if the particular div is null.
    }
});
});

/*Add to favourites functions*/
$(function(){

    $(".resortFavourites").on("click", function(){    //Creating a function onclick.

        try{
            $(".resortFavourites").attr("disabled",true);     //Make the button dissable.

            var resortIDToAdd = $(this).closest("p").attr("id");      // get the p tag id.

            var favouriteResort = JSON.parse(localStorage.getItem("favouriteResortLocal"));   //Getting whats inside local Storage 

            if(favouriteResort  == null){    //Checking whether the local storage is null.

                favouriteResort  = [];
            }

            if(favouriteResort != null){    //Checking whether the local storage is not null.

                for(var i = 0; i < favouriteResort .length; i++){    //loop to iterate among the local storage.
                    
                    if(resortIDToAdd== favouriteResort[i]){  //Checking whether the local storage has the same ID.

                        alert("Resort is already added to the list of favourites.");    //An alert.

                        favouriteResort = [];
                    }
                }
            }

            favouriteResort.push(resortIDToAdd);  //Pushing the ID to the local storage.

            localStorage.setItem("favouriteResortLocal",JSON.stringify(favouriteResort));  //Conversion of JS object in to string.

            alert("The Resort has been added to favourites.");    //Display an alert.
        }

        catch(e){
            console.log("Error has been occured");   // display an error message in the console.
        }
    });
});

/*remove favourites funcion*/
$(function(){       //Creating function

    $(".resortRemove").on("click",function(){     //Creating an on click event on a button.

        $(this).attr("disabled",true);      //Disable the button once clicked.

        var resortToRemove = $(this).closest("p").attr("id");     //Getting the ID whats inside the p tag.

        favouriteResort = JSON.parse(localStorage.getItem("favouriteResortLocal"));    //Getting items from the local storage

        if(favouriteResort != null){        //Checking whether the local storage is null.

            for(var i = 0; i < favouriteResort.length; i++){    //Iterating inside the local storage using a for loop.

                if(resortToRemove == favouriteResort[i]){     //Checking whether the property is there and remove. 

                    alert("This resort has been removed");     //Display alert.

                    delete favouriteResort[i];      //Delete the property.

                    localStorage.setItem("favouriteResortLocal", JSON.stringify(favouriteResort));//Converting json object to string 

                    favouriteResort[i] = [];

                }
            }
        }

        if(favouriteResort == null){
            alert("No more favourite resorts to be removed.");  //Display alert.
        }
    });
});

//view added favourite resorts

$(function(){   //Creating a function
    $("#btnFavouriteResort").on("click", function(){  
        
        //Creating an on click event.
        console.log("Restoring array data from local storage ")
        var veiwFavouriteResortDiv = document.getElementById("viewFavouriteArea");          //Getting the element by ID.

        favouriteResort = JSON.parse(localStorage.getItem("favouriteResortLocal"));    //Getting items from the local storage.

        var outPutOfFavourites = "";   //Variable of String used to concatenate the favourite results.     

        if(favouriteResort != null){    //Checking whehter the local storage is not empty.

            for(var i=0; i< data.resorts.length; i++){   //Looping around the json data.

                for(j=0; j < favouriteResort .length; j++){      //Looping around the local storage.

                    if(data.resorts[i].id == favouriteResort[j]){    //Checking equal results from json data and local storage.

                       outPutOfFavourites+="<h2 id='favePrice'><li>" + "Price : £" +data.resorts[i].price+ "</li></h2>" + "<a href="+data.resorts[i].url+"> <img src="+data.resorts[i].picture+" id='favImage'> </a>" + "<p id='favParagraph'>" +data.resorts[i].short_description+ "</p>" + "<h2 id='favName'>" + "Name : "+ "</h2><br><hr>";      //Concatenation of the favourite result.
                
                    }
                }
            }
        }

        veiwFavouriteResortDiv.insertAdjacentHTML("beforeend", outPutOfFavourites);  //Output of the data in the div.
        if(document.getElementById("viewFavouriteArea").innerHTML ==""){ //Display an alert if the div is empty.
            alert("Sorry No Results Found. \n\n"+"  Try Again !");
        }
    });
}); 

$(function(){       //Create a function
    $("#btnClearResorts").on("click",function(){       //Creating an onclick event.

        $("#viewFavouriteArea").html("");      //Once clear button is clicked the div get cleared.
        
        favouriteResort = JSON.parse(localStorage.getItem("favouriteResortLocal"));    //Get items from the local storage.

        localStorage.clear();       //Clearing the local storage.

        alert("Favourites are cleared !");  //Display alert.
    });
});









